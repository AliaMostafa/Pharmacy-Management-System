import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class PharmacyApp 
{

    private static int limit;
    private static int count = 0;
    private static double dailySales = 0.0;
    private static Map<Integer, Drug> drugs = new HashMap<>();

    public static void main(String[] args) 
    {

        JFrame frame = new JFrame("Nu Pharmacy Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon icon = new ImageIcon("logo-1.png");
        frame.setIconImage(icon.getImage());
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        JPanel buttonPanel = new JPanel(new GridLayout(6, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(new Color(240, 248, 255));

        JButton addDrugButton = createStyledButton("Add Drug", new Color(70, 130, 180));
        addDrugButton.setFont(new Font("Bahnschrift", Font.BOLD, 25));
        JButton removeDrugButton = createStyledButton("Remove Drug", new Color(70, 130, 180));
        removeDrugButton.setFont(new Font("Bahnschrift", Font.BOLD, 25));
        JButton placeOrderButton = createStyledButton("Place an Order", new Color(70, 130, 180));
        placeOrderButton.setFont(new Font("Bahnschrift", Font.BOLD, 25));
        JButton totalSalesButton = createStyledButton("Get Total Sales", new Color(70, 130, 180));
        totalSalesButton.setFont(new Font("Bahnschrift", Font.BOLD, 25));
        JButton displayInventoryButton = createStyledButton("Display Inventory", new Color(70, 130, 180));
        displayInventoryButton.setFont(new Font("Bahnschrift", Font.BOLD, 25));
        JButton exitButton = createStyledButton("Exit", new Color(220, 20, 60));
        exitButton.setFont(new Font("Bahnschrift", Font.BOLD, 40));

        buttonPanel.add(addDrugButton);
        buttonPanel.add(removeDrugButton);
        buttonPanel.add(placeOrderButton);
        buttonPanel.add(totalSalesButton);
        buttonPanel.add(displayInventoryButton);
        buttonPanel.add(exitButton);

        panel.add(buttonPanel, BorderLayout.CENTER);

        frame.getContentPane().add(panel);
        frame.setVisible(true);

        addDrugButton.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                if (count < limit) 
                {
                    JTextField nameField = new JTextField();
                    JTextField idField = new JTextField();
                    JTextField priceField = new JTextField();
                    String[] categories = {"Prescription drug", "Cosmetics drug", "Other"};
                    JComboBox<String> categoryBox = new JComboBox<>(categories);
                    JTextField quantityField = new JTextField();

                    JPanel addPanel = new JPanel(new GridLayout(6, 2));
                    
                    addPanel.add(new JLabel("Drug Name:"));
                    addPanel.add(nameField);
                    addPanel.add(new JLabel("Drug ID:"));
                    addPanel.add(idField);
                    addPanel.add(new JLabel("Price:"));
                    addPanel.add(priceField);
                    addPanel.add(new JLabel("Category:"));
                    addPanel.add(categoryBox);
                    addPanel.add(new JLabel("Quantity:"));
                    addPanel.add(quantityField);

                    int result = JOptionPane.showConfirmDialog(null, addPanel, "Add Drug", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) 
                    {
                        try 
                        {
                            String name = nameField.getText();
                            int id = Integer.parseInt(idField.getText());
                            double price = Double.parseDouble(priceField.getText());
                            String category = (String) categoryBox.getSelectedItem();
                            int quantity = Integer.parseInt(quantityField.getText());

                            if (id < 0 || price < 0 || quantity < 0) 
                            {
                                throw new IllegalArgumentException("ID, price, and quantity must be non-negative.");
                            }

                            drugs.put(id, new Drug(name, id, price, category, quantity));
                            count++;
                        } 
                        catch (NumberFormatException ex) 
                        {
                            JOptionPane.showMessageDialog(null, "Please enter valid numeric values for ID, price, and quantity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                        } 
                        catch (IllegalArgumentException ex) 
                        {
                            JOptionPane.showMessageDialog(null, ex.getMessage(), "Invalid Input", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "Pharmacy capacity reached!");
                }
            }
        });

        removeDrugButton.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                try 
                {
                    String idString = JOptionPane.showInputDialog("Enter the drug ID to remove:");
                    if (idString != null) {
                        int id = Integer.parseInt(idString);
                        if (drugs.containsKey(id)) {
                            drugs.remove(id);
                            count--;
                            JOptionPane.showMessageDialog(null, "Drug removed successfully!");
                        } else {
                            JOptionPane.showMessageDialog(null, "Drug does not exist!");
                        }
                    }
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(null, "Please enter a valid numeric ID.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        placeOrderButton.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                try 
                {
                    String idString = JOptionPane.showInputDialog("Enter the drug ID to order:");
                    if (idString != null) 
                    {
                        int id = Integer.parseInt(idString);
                        Drug drug = drugs.get(id);

                        if (drug != null) 
                        {
                            if (drug.getQuantity() > 0)
                            {
                                if (drug.getCategory().equalsIgnoreCase("Prescription drug")) 
                                {
                                    String prescription = JOptionPane.showInputDialog("Enter the prescription:");
                                    if (!prescription.isEmpty()) 
                                    {
                                        JOptionPane.showMessageDialog(null, "Price of the drug is: " + drug.getPrice());
                                        dailySales += drug.getPrice();
                                        drug.setQuantity(drug.getQuantity() - 1);
                                    } 
                                    else 
                                    {
                                        JOptionPane.showMessageDialog(null, "Cannot sell without a prescription.");
                                    }
                                } 
                                else 
                                {
                                    double price = drug.getCategory().equalsIgnoreCase("Cosmetics drug") ? drug.getPrice() * 1.0 : drug.getPrice();
                                    JOptionPane.showMessageDialog(null, "Price of the drug is: " + price);
                                    dailySales += price;
                                    drug.setQuantity(drug.getQuantity() - 1);
                                }
                                if (drug.getQuantity() == 0) 
                                {
                                    JOptionPane.showMessageDialog(null, "The drug is now out of stock!");
                                }
                            } 
                            else 
                            {
                                JOptionPane.showMessageDialog(null, "The drug is out of stock!");
                            }
                        } 
                        else 
                        {
                            JOptionPane.showMessageDialog(null, "Drug does not exist!");
                        }
                    }
                } 
                catch (NumberFormatException ex) 
                {
                    JOptionPane.showMessageDialog(null, "Please enter a valid numeric ID.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        totalSalesButton.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                JOptionPane.showMessageDialog(null, "Total sales per day: " + dailySales);
            }
        });

        displayInventoryButton.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                DefaultTableModel model = new DefaultTableModel();
                model.addColumn("Name");
                model.addColumn("ID");
                model.addColumn("Price");
                model.addColumn("Category");
                model.addColumn("Quantity");

                for (Drug drug : drugs.values()) 
                {
                    model.addRow(new Object[]{drug.getName(), drug.getId(), drug.getPrice(), drug.getCategory(), drug.getQuantity()});
                }

                JTable table = new JTable(model);

                JScrollPane scrollPane = new JScrollPane(table);

                JOptionPane.showMessageDialog(null, scrollPane, "Inventory", JOptionPane.PLAIN_MESSAGE);
            }
        });

        exitButton.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                JOptionPane.showMessageDialog(null, "Program exited successfully.");
                System.exit(0);
            }
        });

        try 
        {
            String capacityString = JOptionPane.showInputDialog("Enter the capacity of the pharmacy:");
            if (capacityString != null) 
            {
                limit = Integer.parseInt(capacityString);
                if (limit < 0) 
                {
                    throw new IllegalArgumentException("Capacity must be non-negative.");
                }
            }
        } 
        catch (NumberFormatException ex) 
        {
            JOptionPane.showMessageDialog(null, "Please enter a valid numeric value for capacity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } 
        catch (IllegalArgumentException ex) 
        {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Invalid Input", JOptionPane.ERROR_MESSAGE);
            System.exit(1); //1 indicates program terminated with errors
        }
    }

    private static JButton createStyledButton(String text, Color color) 
    {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setPreferredSize(new Dimension(200, 50));
        button.setBorder(BorderFactory.createRaisedBevelBorder());
        button.setToolTipText(text);
        return button;
    }
}

class Drug 
{
    private String name;
    private int id;
    private double price;
    private String category;
    private int quantity;

    public Drug(String name, int id, double price, String category, int quantity) 
    {
        this.name = name;
        this.id = id;
        this.price = price;
        this.category = category;
        this.quantity = quantity;
    }

    public String getName() 
    {
        return name;
    }

    public int getId() 
    {
        return id;
    }

    public double getPrice() 
    {
        return price;
    }

    public String getCategory() 
    {
        return category;
    }

    public int getQuantity() 
    {
        return quantity;
    }

    public void setQuantity(int quantity) 
    {
        this.quantity = quantity;
    }
}